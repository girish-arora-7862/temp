import React from "react";
import { createNativeStackNavigator } from "@react-navigation/native-stack";
import {
  createDrawerNavigator,
  DrawerItemList,
} from "@react-navigation/drawer";
import { useDispatch, useSelector } from "react-redux";
import HomeScreen from "../screens/HomeScreen";
import DetailScreen from "../screens/DetailScreen";
import AboutScreen from "../screens/AboutScreen";
import LoginScreen from "../screens/LoginScreen";
import { Ionicons } from "@expo/vector-icons";
import { NavigationContainer } from "@react-navigation/native";
import { View, Button, SafeAreaView } from "react-native";
import { UserActions } from "../store/reducer/user";

const ToDoStack = createNativeStackNavigator();

const ToDoNavigator = () => {
  return (
    <ToDoStack.Navigator>
      <ToDoStack.Screen name="Home" component={HomeScreen} />
      <ToDoStack.Screen name="Detail" component={DetailScreen} />
    </ToDoStack.Navigator>
  );
};

// const AboutStack = createNativeStackNavigator();

// const AboutNavigator = () => {
//   return (
//     <AboutStack.Navigator>
//       <AboutStack.Screen name="AboutScreen" component={AboutScreen} />
//     </AboutStack.Navigator>
//   );
// };

const AuthStack = createNativeStackNavigator();

const AuthNavigator = () => {
  return (
    <AuthStack.Navigator>
      <AuthStack.Screen name="Auth" component={LoginScreen} />
    </AuthStack.Navigator>
  );
};

const Drawer = createDrawerNavigator();

const DrawerNavigator = () => {
  return (
    <Drawer.Navigator drawerContent={(props) => <DrawerContent {...props} />}>
      <Drawer.Screen
        name="Todo"
        component={ToDoNavigator}
        options={{
          drawerIcon: (drawerConfig) => (
            <Ionicons name="md-cart" size={23} color="#664488" />
          ),
        }}
      />
      <Drawer.Screen
        name="About"
        component={AboutScreen}
        options={{
          drawerIcon: (drawerConfig) => (
            <Ionicons name="md-cart" size={23} color="#664488" />
          ),
        }}
      />
    </Drawer.Navigator>
  );
};

const DrawerContent = (props) => {
  const dispatch = useDispatch();
  return (
    <View style={{ flex: 1, paddingTop: 20 }}>
      <SafeAreaView forceInset={{ top: "always", horizontal: "never" }}>
        <DrawerItemList {...props} />
        <Button
          title="Logout"
          onPress={() => {
            dispatch(UserActions.logout());
          }}
        />
      </SafeAreaView>
    </View>
  );
};

const MainNavigator = () => {
  const isLoggedIn = useSelector((state) => state.user.isLoggedIn);

  return (
    <NavigationContainer>
      {!isLoggedIn && <AuthNavigator />}
      {isLoggedIn && <DrawerNavigator />}
    </NavigationContainer>
  );
};

export default MainNavigator;
