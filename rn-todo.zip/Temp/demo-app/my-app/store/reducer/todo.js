import { createSlice } from "@reduxjs/toolkit";

const initialState = {
  todos: [],
};

export const counterSlice = createSlice({
  name: "todo",
  initialState,
  reducers: {
    addTodo: (state, action) => {
      state.todos.push(action.payload);
    },
    replaceTodos: (state, action) => {
      state.todos = action.payload;
    },
    removeTodo: (state, action) => {
      let filteredTodo = state.todos.filter(
        (todo) => todo.id != action.payload
      );
      state.todos = filteredTodo;
    },
  },
});

export const ToDoActions = counterSlice.actions;

export default counterSlice.reducer;
