import { configureStore } from "@reduxjs/toolkit";
import TodoReducer from "./reducer/todo";
import UserReducer from "./reducer/user";

export default configureStore({
  reducer: {
    todo: TodoReducer,
    user: UserReducer,
  },
});
