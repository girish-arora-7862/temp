import React, { useEffect, useState } from "react";
import { View, Text, StyleSheet, Button, SafeAreaView } from "react-native";
import { TouchableWithoutFeedback } from "react-native-gesture-handler";
import { HeaderButtons, Item } from "react-navigation-header-buttons";
import { useDispatch, useSelector } from "react-redux";
import getTodo from "../api/getTodo";
import saveTodo from "../api/saveTodo";
import Card from "../components/Card";
import HeaderButton from "../components/HeaderButton";
import TodoModal from "../components/TodoModal";
import { ToDoActions } from "../store/reducer/todo";

const generateId = () => {
  return Date.now().toString();
};

const HomeScreen = (props) => {
  const dispatch = useDispatch();
  const [showModal, setShowModal] = useState(false);
  const todos = useSelector((state) => state.todo.todos);
  const userId = useSelector((state) => state.user.id);
  const token = useSelector((state) => state.user.token);

  const addTodoHandler = async (title, description) => {
    setShowModal(false);
    const response = await saveTodo(userId, { title, description }, token);
    dispatch(ToDoActions.addTodo({ title, description, id: response.name }));
  };

  useEffect(() => {
    (async () => {
      const response = await getTodo(userId, token);
      let list = [];
      for (const [key, value] of Object.entries(response)) {
        list.push({ id: key, ...value });
      }
      dispatch(ToDoActions.replaceTodos(list));
    })();
  }, []);

  const showDetailHandler = (id) => {
    props.navigation.navigate("Detail", {
      id: id,
    });
  };

  return (
    <View style={styles.screen}>
      <View style={styles.button}>
        <Button title="Add To Do" onPress={() => setShowModal(true)} />
      </View>
      <TodoModal visible={showModal} addTodoHandler={addTodoHandler} />
      {todos.map((todo) => (
        <TouchableWithoutFeedback
          key={todo.id}
          style={styles.cardCover}
          onPress={() => showDetailHandler(todo.id)}
        >
          <Card style={styles.card}>
            <Text>{todo.title}</Text>
          </Card>
        </TouchableWithoutFeedback>
      ))}
    </View>
  );
};

HomeScreen.navigationOptions = (navData) => {
  return {
    headerTitle: "To Do List",
    headerLeft: (
      <HeaderButtons HeaderButtonComponent={HeaderButton}>
        <Item
          title="Menu"
          iconName="ios-menu"
          onPress={() => {
            navData.navigation.toggleDrawer();
          }}
        />
      </HeaderButtons>
    ),
  };
};

const styles = StyleSheet.create({
  screen: {
    flex: 1,
    alignItems: "center",
    padding: 20,
  },
  cardCover: {
    // borderRadius: 10,
    padding: 5,
    width: 350,
    overflow: "hidden",
  },
  card: {
    width: "100%",
    marginBottom: 20,
  },
  button: {
    marginBottom: 20,
    width: 200,
  },
});

export default HomeScreen;
