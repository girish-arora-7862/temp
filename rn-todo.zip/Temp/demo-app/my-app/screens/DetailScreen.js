import React from "react";
import { View, Text, StyleSheet } from "react-native";
import { useSelector } from "react-redux";
import Card from "../components/Card";

const DetailScreen = (props) => {
  const id = props.route.params.id;
  // const id = props.navigation.getParam("id");
  const todo = useSelector((state) =>
    state.todo.todos.find((curr) => curr.id == id)
  );
  return (
    <View style={styles.screen}>
      <Text>Title</Text>
      <Card style={styles.card}>
        <Text>{todo.title}</Text>
      </Card>
      <Text>Description</Text>
      <Card style={styles.card}>
        <Text>{todo.description}</Text>
      </Card>
    </View>
  );
};

const styles = StyleSheet.create({
  screen: {
    flex: 1,
    alignItems: "flex-start",
    padding: 20,
  },
  card: {
    width: "100%",
    marginBottom: 20,
    marginTop: 10,
  },
});

export default DetailScreen;
