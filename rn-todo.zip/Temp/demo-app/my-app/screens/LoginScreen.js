import React, { useState } from "react";
import { View, Text, StyleSheet, Button, TextInput, Alert } from "react-native";
import { useDispatch } from "react-redux";
import loginAPI from "../api/loginAPI";
import signUpAPI from "../api/signUpAPI";
import { UserActions } from "../store/reducer/user";

const LoginScreen = (props) => {
  const dispatch = useDispatch();
  const [isLogin, setIsLogin] = useState(true);
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");

  const loginHandler = async () => {
    if (email && password) {
      try {
        let response;
        if (isLogin) {
          response = await loginAPI(email, password);
        } else {
          response = await signUpAPI(email, password);
        }
        dispatch(
          UserActions.login({
            id: response.localId,
            token: response.idToken,
          })
        );
      } catch (error) {
        Alert.alert(
          "Wrong input!",
          isLogin ? "Invalid Username/Password" : "Sign Up Failed",
          [{ text: "Okay" }]
        );
      }
    } else {
      Alert.alert("Wrong input!", "Username & Password Is Required", [
        { text: "Okay" },
      ]);
    }
  };

  return (
    <View style={styles.screen}>
      <View style={styles.inputGroup}>
        <Text style={styles.label}>Email</Text>
        <TextInput
          placeholder="Email"
          style={styles.input}
          onChangeText={(value) => setEmail(value)}
          value={email}
        />
      </View>
      <View style={styles.inputGroup}>
        <Text style={styles.label}>Password</Text>
        <TextInput
          placeholder="Password"
          style={styles.input}
          onChangeText={(value) => setPassword(value)}
          value={password}
        />
      </View>
      {isLogin && (
        <View>
          <View style={styles.button}>
            <Button
              style={styles.button}
              title="Login"
              onPress={loginHandler}
            />
          </View>
          <View style={styles.button}>
            <Button
              style={styles.button}
              title="Switch To Sign Up"
              onPress={() => setIsLogin(false)}
            />
          </View>
        </View>
      )}
      {!isLogin && (
        <View>
          <View style={styles.button}>
            <Button title="Sign Up" onPress={loginHandler} />
          </View>
          <View style={styles.button}>
            <Button title="Switch To Login" onPress={() => setIsLogin(true)} />
          </View>
        </View>
      )}
    </View>
  );
};

const styles = StyleSheet.create({
  screen: {
    padding: 20,
    flex: 1,
    alignItems: "center",
    justifyContent: "center",
  },
  inputGroup: {
    width: "100%",
    marginBottom: 20,
  },
  input: {
    paddingTop: 10,
    width: "100%",
    borderColor: "grey",
    borderBottomWidth: 1,
  },
  label: {
    alignSelf: "flex-start",
  },
  button: {
    width: 200,
    marginBottom: 20,
  },
});

export default LoginScreen;
