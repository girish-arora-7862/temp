import React from "react";
import { View, Text, StyleSheet } from "react-native";
import HeaderButton from "../components/HeaderButton";
import { HeaderButtons, Item } from "react-navigation-header-buttons";

const AboutScreen = () => {
  return (
    <View style={styles.screen}>
      <Text>About Screen</Text>
    </View>
  );
};

AboutScreen.navigationOptions = (navData) => {
  return {
    headerTitle: "About",
    headerLeft: (
      <HeaderButtons HeaderButtonComponent={HeaderButton}>
        <Item
          title="Menu"
          iconName="ios-menu"
          onPress={() => {
            navData.navigation.toggleDrawer();
          }}
        />
      </HeaderButtons>
    ),
  };
};

const styles = StyleSheet.create({
  screen: {
    flex: 1,
    alignItems: "center",
    justifyContent: "center",
  },
});

export default AboutScreen;
