import axios from "axios";
import { API_KEY } from "../const/strings";

const saveTodo = async (id, todo, token) => {
  const response = await axios.post(
    `https://temp-e9fc1-default-rtdb.firebaseio.com/users/${id}.json?auth=${token}`,
    todo
  );
  return response.data;
};

export default saveTodo;
