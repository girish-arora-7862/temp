import axios from "axios";
import { API_KEY } from "../const/strings";

const getTodo = async (id, token) => {
  const response = await axios.get(
    `https://temp-e9fc1-default-rtdb.firebaseio.com/users/${id}.json?auth=${token}`
  );
  return response.data;
};

export default getTodo;
