import React, { useState } from "react";
import {
  View,
  TextInput,
  Button,
  StyleSheet,
  Modal,
  Text,
  Alert,
} from "react-native";

const TodoModal = (props) => {
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");

  const addTodoHandler = () => {
    if (title && description) {
      props.addTodoHandler(title, description);
      setTitle("");
      setDescription("");
    } else {
      Alert.alert("Wrong input!", "Title & Description Is Required", [
        { text: "Okay" },
      ]);
    }
  };

  return (
    <Modal visible={props.visible} animationType="slide">
      <View style={styles.inputContainer}>
        <View style={styles.inputGroup}>
          <Text style={styles.label}>Title</Text>
          <TextInput
            placeholder="Title"
            style={styles.input}
            onChangeText={(value) => setTitle(value)}
            value={title}
          />
        </View>
        <View style={styles.inputGroup}>
          <Text style={styles.label}>Description</Text>
          <TextInput
            placeholder="Description"
            style={styles.input}
            onChangeText={(value) => setDescription(value)}
            value={description}
          />
        </View>
        <View style={styles.button}>
          <Button title="Add Todo" onPress={addTodoHandler} />
        </View>
      </View>
    </Modal>
  );
};

const styles = StyleSheet.create({
  inputContainer: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
    padding: 20,
  },
  inputGroup: {
    width: "100%",
    marginBottom: 20,
  },
  input: {
    paddingTop: 10,
    width: "100%",
    borderColor: "grey",
    borderBottomWidth: 1,
  },
  label: {
    alignSelf: "flex-start",
  },
  button: {
    width: 200,
    marginBottom: 20,
  },
});

export default TodoModal;
