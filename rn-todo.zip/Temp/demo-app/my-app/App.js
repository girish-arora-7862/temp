import "react-native-gesture-handler";
import React from "react";
import { StatusBar, StyleSheet, Text, View } from "react-native";
import store from "./store/store";
import { Provider } from "react-redux";
import Navigator from "./navigator/navigator";

export default function App() {
  return (
    <Provider store={store}>
      <StatusBar style={styles.statusBar} />
      <Navigator />
    </Provider>
  );
}

const styles = StyleSheet.create({
  statusBar: { height: 0 },
  container: {
    flex: 1,
    backgroundColor: "#fff",
    alignItems: "center",
    justifyContent: "center",
  },
});
