export const API_KEY = "AIzaSyAdbu4IDE7p7Y1MxgZ0nauU59UXnmUPrP8";
