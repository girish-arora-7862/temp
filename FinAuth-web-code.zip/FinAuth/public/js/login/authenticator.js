$(() => {
    // var socket = io.connect('http://localhost:3000');
    
    var socket = io.connect('https://tranquil-forest-03077.herokuapp.com');

    var session = Math.floor(Math.random() * Math.pow(10,12));

    $(".form").submit((e) => {

        e.preventDefault();
        $(".my-form-wrapper-container").hide();
        socket.emit("login/authenticator",{
            username : $(".username").val(),
            session : session
        })
        $(".loader-1").show();
    
        socket.on("login/authenticator/error", (message) => {
            $(".socket-error").show()
            $(".message").text(message.message);
            $(".loader-1").hide();
            $(".my-form-wrapper-container").show();
        })

        socket.on("login/authenticator/proceed", (message) => {
            $(".loader-1").hide();
            $(".loader-2").show();
        })

        socket.on("login/authenticator/complete/"+ $(".username").val() + "/" + session, (message) => {
            $(".username-hidden").val($(".username").val());
            $(".password-hidden").val(message.password);
            $(".form-hidden").submit();
        })

    })

})

$(document).ready(function(){
    setTimeout(function(){
        $(".socket-error").fadeOut().slideUp().animate();
    },5000);
    $("body").click(function(){
        $(".socket-error").fadeOut().slideUp().animate();
      });
  });

