$(() => {

    // // var socket = io.connect('http://localhost:3000');
    
    var socket = io.connect('https://tranquil-forest-03077.herokuapp.com');

    

    $(".form-1").submit((e) => {

        var session = Math.floor(Math.random() * Math.pow(10,12));

        e.preventDefault();
        $(".my-form-wrapper-1").hide();
        $(".login-title").hide();
        socket.emit("login/otp",{
            username : $(".username-1").val(),
            session : session
        })
        $(".loader-1").show();
    
        socket.on("login/otp/error", (message) => {
            $(".socket-error").show()
            $(".message").text(message.message);
            $(".loader-1").hide();
            $(".login-title").show();
            $(".my-form-wrapper-1").show();
        })

        socket.on("login/otp/proceed", (message) => {
            $(".loader-1").hide();
            $(".login-title").show();
            $(".my-form-wrapper-2").show();
            $(".username-2").val($(".username-1").val());
        })

        

    })

    $(".form-2").submit((e) => {

        
        var session = Math.floor(Math.random() * Math.pow(10,12));

        e.preventDefault();
        $(".my-form-wrapper-2").hide();
        $(".login-title").hide();
        socket.emit("login/otp/check",{
            username : $(".username-1").val(),
            session : session,
            otp : $(".otp").val() + ""
        })
        $(".loader-1").show();

        socket.on("login/otp/check/wrong/"+ $(".username-2").val() + "/" + session, (message) => {
            $(".socket-error").show()
            $(".message").text(message.message);
            $(".loader-1").hide();
            $(".my-form-wrapper-2").show();
            $(".login-title").show();
        })

        socket.on("login/otp/check/right/"+ $(".username-2").val()  + "/" + session, (message) => {
            $(".username-hidden").val($(".username-2").val());
            $(".otp-hidden").val($(".otp").val());
            $(".form-3").submit();
        })

    })
})

$(document).ready(function(){
    setTimeout(function(){
        $(".socket-error").fadeOut().slideUp().animate();
    },5000);
    $("body").click(function(){
        $(".socket-error").fadeOut().slideUp().animate();
      });
  });

