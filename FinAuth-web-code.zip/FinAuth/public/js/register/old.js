$(() => {
    // var socket = io.connect('http://localhost:3000');
    
    var socket = io.connect('https://tranquil-forest-03077.herokuapp.com');

    // make otp
    var otp = Math.floor(Math.random() * (999999 - 100000) + 100000);
    
    
    socket.emit("register/old",{
        username : $(".username-hidden").val(),
        otp : otp,
        type : "old"
    })

    $(".loader-username").text("Username : " + $(".username-hidden").val());
    $(".loader-otp").text("OTP : " + otp);

    socket.on("register/old/complete/"+ $(".username-hidden").val(), (message) => {
        $(".form-hidden-2").submit();
    })

    
    
})


$(document).ready(function(){
    setTimeout(function(){
        $(".socket-error").fadeOut().slideUp().animate();
    },5000);
    $("body").click(function(){
        $(".socket-error").fadeOut().slideUp().animate();
      });
  });


