$(() => {
    // var socket = io.connect('http://localhost:3000');
    
    var socket = io.connect('https://tranquil-forest-03077.herokuapp.com');

    // make otp
    var otp = Math.floor(Math.random() * (999999 - 100000) + 100000);  

    $(".form").submit((e) => {
        e.preventDefault();
        $(".my-form-wrapper-container").hide();
        socket.emit("register/new",{
            username : $(".username").val(),
            otp : otp,
            type : "new"
        })

        $(".loader-username").text("Username : " + $(".username").val());
        $(".loader-otp").text("OTP : " + otp);
        $(".loader-1").show();

        socket.on("register/new/error", (message) => {
            $(".socket-error").show()
            $(".message").text(message.message);
            $(".loader-1").hide();
            $(".my-form-wrapper-container").show();
        })

        socket.on("register/new/proceed", (message) => {
            $(".loader-1").hide();
            $(".loader-2").show();
        })

    
        socket.on("register/new/complete/"+ $(".username").val(), (message) => {
            $(".username-hidden").val($(".username").val());
            $(".password-hidden").val(message.password);
            $(".email-hidden").val($(".email").val())
            $(".form-hidden").submit();
        })

    })
    
})


$(document).ready(function(){
    setTimeout(function(){
        $(".socket-error").fadeOut().slideUp().animate();
    },5000);
    $("body").click(function(){
        $(".socket-error").fadeOut().slideUp().animate();
      });
  });


