$(document).ready(function(){
    setTimeout(function(){
        $(".flash").fadeOut().slideUp().animate();
    },5000);
    $("body").click(function(){
        $(".flash").fadeOut().slideUp().animate();
      });
  });

