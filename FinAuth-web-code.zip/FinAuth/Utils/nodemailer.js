var nodemailer = require("nodemailer");
var dotenv = require('dotenv');
dotenv.config();

var obj = {}

let transporter = nodemailer.createTransport({
    host: "smtp.gmail.com",
    port: 465,
    secure: true,
    service : 'Gmail',
    
    auth: {
      user: process.env.GMAIL_ID,
      pass: process.env.GMAIL_PASSWORD,
    }
    
});

obj.sendEmail = (email,otp,next) => {
     // send mail with defined transport object
    var mailOptions = {
        to: email,
        subject: "FinAuth Login OTP",
        html: "<h3>Your FinAuth Login OTP is </h3>"  + "<h1 style='font-weight:bold;'>" + otp +"</h1>"
    };
     
     transporter.sendMail(mailOptions, (error, info) => {
        if (error) {
            return console.log("Error Sending Email")
        } else {
            next(info);
        }
    });
}

module.exports = obj;