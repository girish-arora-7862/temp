var User = require("./DB/user");
var Hash = require("./DB/hash");
var util = {}

util.registerUser = (req,res,username,password,email,failureRedirect,next) => {
    User.registerUser(req,res,username,password,failureRedirect, (userDoc) => {
        Hash.addUser(req,res,username,password,email,failureRedirect, (hashDoc) => {
            util.loginUserWithPassword(req,res,username,password,failureRedirect,() => {                                                                                                    
                next(hashDoc,userDoc);
            })
        })
    })
}

util.loginUserWithoutPassword = (req,res,username,failureRedirect,next) => {
    Hash.findUserWithUsername(req,res,username,failureRedirect, (hashDoc) => {
        User.loginUser(req,res,username,hashDoc.password,failureRedirect, () => {
            next();
        })
    })
}

util.loginUserWithPassword = (req,res,username,password,failureRedirect,next) => {
    User.loginUser(req,res,username,password,failureRedirect, () => {
        next();
    })
}

util.findUserWithUsername = (req,res,username,failureRedirect,next) => {
    Hash.findUserWithUsername(req,res,username,failureRedirect, (hashDoc) => {
        next(hashDoc);
    })
}

util.checkIfUserExists = (req,res,username,failureRedirect,next) => {
    Hash.findUserWithUsername(req,res,username,failureRedirect, (hashDoc) => {
        next();
    })
}

util.generatePassword = () => {
    var length = 32,
        charset = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789",
        retVal = "";
    for (var i = 0, n = charset.length; i < length; ++i) {
        retVal += charset.charAt(Math.floor(Math.random() * n));
    }
    return retVal;
}

util.generateOTP = () => {
    return Math.floor(Math.random() * (999999 - 100000) + 100000);  
}

module.exports = util;