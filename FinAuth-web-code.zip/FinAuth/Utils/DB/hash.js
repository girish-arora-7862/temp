var Hash = require("../../models/hash");
var util = {}


util.addUser = (req,res,username,password,email,failureRedirect,next) => {
    // create user hash
    var hash = new Hash({
        username : username,
        password : password,
        email : email
    });
    // save user hash
    hash.save((err,hashDoc) => {
        if(err){
            req.flash("error","Error Creating User Hash");
            res.redirect(failureRedirect);
        } else {
            next(hashDoc);
        }
    })
}

util.findUserWithUsername = (req,res,username,failureRedirect,next) => {
    Hash.findOne({username : username}, (err,hashDoc) => {
        if(err){
            req.flash("error","User Does Not Exist");
            res.redirect(failureRedirect);
        } else {
            if(hashDoc){
                next(hashDoc);
            } else {
                req.flash("error","User Does Not Exist");
                res.redirect(failureRedirect);
            }
        }
    })
}

module.exports = util;