var User = require("../../models/user");
var passport = require("passport");
var util = {}


util.registerUser = function(req,res,username,password,failureRedirect,next){
    // register user
    User.register({username : username},password,function(err,user){
        if(err){
            req.flash("error",err.message);
            res.redirect(failureRedirect);
        } else {
            next(user);
        }
    })
}


util.loginUser = function(req,res,username,password,failureRedirect,next){
    const user = new User({
        username : username,
        password : password
    })
    console.log(user);
    req.login(user,function(err){
        if(err){
            req.flash("error",err.message)
            res.redirect(failureRedirect);
        } else {
            next();
        }
    })
}

module.exports = util;