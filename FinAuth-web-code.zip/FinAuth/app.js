var express = require('express'); 
var socketIO = require('socket.io'); 
var http = require('http');
var bodyParser = require("body-parser");
var admin = require("firebase-admin");
var flash = require("connect-flash");
var session = require('express-session'); 
var passport = require("passport");
var LocalStrategy   = require("passport-local");
var mongoose = require("mongoose");
var User = require("./models/user");
var serviceAccount = require("./finauth-cebcd-firebase-adminsdk-n7pf0-86890bcfd0.json");
var util = require("./Utils/util")
var Hash = require("./models/hash");
var nodemailer = require("./Utils/nodemailer")


var app = express(); 
var server = http.createServer(app) 
var io = socketIO(server); 


var url = process.env.DATABASEURL || "mongodb://localhost/finauth_db";
mongoose.connect(url,{ 
    useNewUrlParser: true, 
    useUnifiedTopology: true, 
    useCreateIndex: true 
});

app.use(bodyParser.urlencoded({extended: true}));
app.set("view engine", "ejs");
app.use(express.static(__dirname + "/public"));
app.use(flash());

app.use(session({
    secret: "This is our secret",
    resave: false,
    saveUninitialized: false
}));

app.use(passport.initialize());
app.use(passport.session());
passport.use(new LocalStrategy(User.authenticate()));
passport.serializeUser(User.serializeUser());
passport.deserializeUser(User.deserializeUser());

app.use(function(req, res, next){
    res.locals.currentUser = req.user;
    res.locals.error = req.flash("error");
    res.locals.success = req.flash("success");
    next();
 });

var indexRoutes = require("./routes/index");
const e = require('express');

app.use("/", indexRoutes);


//************************* SOCKET IO ***********************/

var otp = {};
var type = {};
var loginOTP ={};
var timeoutHandlerOTP = {};
var timeoutHandlerLoginOTP = {};

// socket programming browser
io.on('connection', (socket)=>{ 

    socket.on("login/authenticator",  (message) => {
        //check if user exists then send notification
        Hash.findOne({username : message.username}, (err,hashDoc) => {
            if(err){
                io.sockets.emit("login/authenticator/error", {
                    message : "User not found"
                });
            } else {
                if(hashDoc){
                    io.sockets.emit("login/authenticator/proceed", {
                        message : "Proceed"
                    }); 
                    sendMessage(message.username,message.session);    
                } else {
                    io.sockets.emit("login/authenticator/error", {
                        message : "User not found"
                    }); 
                }    
            }
        })
    })

    socket.on("login/otp",  (message) => {
        //check if user exists then send notification
        Hash.findOne({username : message.username}, (err,hashDoc) => {
            if(err){
                io.sockets.emit("login/otp/error", {
                    message : "User not found"
                });
            } else {
                if(hashDoc){
                    // TODO : send otp
                    var otp = util.generateOTP() 
                    // save otp in server
                    loginOTP[message.username] = otp;

                    if(timeoutHandlerLoginOTP[message.username]){
                        clearTimeout(timeoutHandlerLoginOTP[message.username]);
                    }
                    timeoutHandlerLoginOTP[message.username] = setTimeout( function() { 
                        delete loginOTP[message.username];
                    }, 15 * 60 * 1000);  
                    nodemailer.sendEmail(hashDoc.email,otp, (info) => {    
                        io.sockets.emit("login/otp/proceed", {
                            message : "Proceed"
                        });
                    }) 
                } else {
                    io.sockets.emit("login/otp/error", {
                        message : "User not found"
                    }); 
                }    
            }
        })
    })

    socket.on("register/new",  (message) => {
        Hash.findOne({username : message.username}, (err,hashDoc) => {
            if(err){
                io.sockets.emit("register/new/error", {
                    message : "Registration Error"
                });
            } else {
                if(hashDoc){
                    io.sockets.emit("register/new/error", {
                        message : "Username Already Taken!"
                    });
                } else {
                    io.sockets.emit("register/new/proceed", {
                        message : "Proceed"
                    });
                    // save otp in server
                    otp[message.username] = message.otp;
                    type[message.username] = "new";
                    if(timeoutHandlerOTP[message.username]){
                        clearTimeout(timeoutHandlerOTP[message.username]);
                    }
                    timeoutHandlerOTP[message.username] = setTimeout( function() { 
                        delete otp[message.username];
                        delete type[message.username];
                    }, 15 * 60 * 1000);
                } 
            }
        })
    })

    socket.on("register/old",  (message) => {
        Hash.findOne({username : message.username}, (err,hashDoc) => {
            if(err){
                io.sockets.emit("register/old/error", {
                    message : "Registration Error"
                });
            } else {
                // save otp in server
                otp[message.username] = message.otp;
                type[message.username] = "old";
                if(timeoutHandlerOTP[message.username]){
                    clearTimeout(timeoutHandlerOTP[message.username]);
                }
                timeoutHandlerOTP[message.username] = setTimeout( function() { 
                    delete otp[message.username];
                    delete type[message.username];
                }, 15 * 60 * 1000); 
            }
        })
    })

    socket.on("login/otp/check",  (message) => {
        console.log("OTP",loginOTP[message.username], message.otp)
        if(loginOTP[message.username] == message.otp){
            io.sockets.emit("login/otp/check/right/" + message.username + "/" + message.session, {
                message : "Proceed"
            });
        } else {
            io.sockets.emit("login/otp/check/wrong/" + message.username + "/" + message.session, {
                message : "Wrong OTP!"
            });
        }
    })

}); 


// firebase setup
admin.initializeApp({
    credential: admin.credential.cert(serviceAccount),
    databaseURL: "https://prismappfcm.firebaseio.com"
});


// firebase notification messaging
var sendMessage = (username,session) => {

    var message = {
          topic: username,
          notification: {
            body: "Tap To Authenticate.",
            title: "Are You Trying To Login?",
          },
          data: {
            username : username,
            session : session + "",
          },
          android: {
            priority: "high",
          },
          apns: {
            headers: {
              "apns-priority": "10",
            },
          },
          webpush: {
            headers: {
              Urgency: "high",
            },
          },
      };
      
    // Send a message to devices subscribed to the provided topic.
    admin.messaging().send(message)
    .then((response) => {
        // console.log('Successfully sent message:', response);
    })
    .catch((error) => {
        console.log('Error sending message:', error);
    });   

}


app.post('/android/login', (req, res) => { 
    io.sockets.emit("login/authenticator/complete/" + req.body.username + "/" + req.body.session, {
        password : req.body.password
    });
    
	res.status(200).json({ 
		message: "JSON Data received successfully" 
	}); 
});


app.post('/android/register', (req, res) => {

    var password = util.generatePassword();
	
    if(otp[req.body.username] == req.body.otp){
        if(type[req.body.username] == "new"){
            io.sockets.emit("register/new/complete/" + req.body.username, {
                password : password
            });
            delete otp[req.body.username];
            delete type[req.body.username];
            res.status(200).json({ 
                message: "OK",
                password : password 
            }); 
        } else {
            util.findUserWithUsername(req,res,req.body.username,"-", (user) => {
                io.sockets.emit("register/old/complete/" + req.body.username, {
                    password : user.password
                });
                delete otp[req.body.username];
                delete type[req.body.username];
                res.status(200).json({ 
                    message: "OK",
                    password : user.password 
                }); 
            })
        }
    } else {
        res.status(200).json({ 
            message: "ERROR" 
        });
    }

    
});

app.post("/login/otp", (req,res) => {
    if(req.body.otp == loginOTP[req.body.username]){
        util.loginUserWithoutPassword(req,res,req.body.username,"/login/otp", () => {
            delete loginOTP[req.body.username];
            req.flash("success","Logged In Successfully...");
            res.redirect("/home");
        })
    } else {
        req.flash("error","Wrong OTP");
        res.redirect("/login/otp");
    }
})

// server.listen(3000,"127.0.0.1",() => {
//         console.log("Server Started at port 3000");
// }); 

server.listen(process.env.PORT,() => {
    console.log("Server Started at port 3000");
}); 
