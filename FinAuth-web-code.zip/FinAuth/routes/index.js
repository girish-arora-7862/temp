var express = require("express");
var router  = express.Router();
var util = require("../Utils/util");


router.get("/", function(req, res){
    res.render("index");
});

router.get("/login/authenticator", (req,res) => {
    res.render("login/authenticator");
})

router.post("/login/authenticator", (req,res) => {
    // login and redirect
    util.loginUserWithPassword(req,res,req.body.username,req.body.password,"/login/authenticator", () => {
        req.flash("success","Successfully Logged In...")
        res.redirect("/home");
    })
})

router.get("/login/otp", (req,res) => {
    res.render("login/otp");
})

router.get("/home", (req,res) => {
    // check authenticated then redirect
    if(req.isAuthenticated()){
        res.render("home",{username : res.locals.currentUser.username});
    } else {
        req.flash("error","Request Unauthorized");
        res.redirect("/login/authenticator");
    }
})

router.post("/register/new",(req,res) => {
    // register login redirect
    util.registerUser(req,res,req.body.username,req.body.password,req.body.email,"/register/new", () => {
        req.flash("success","New User Created Successfully!")
        res.redirect("/home");
    })
})

router.get("/register/old", (req,res) => {
    if(req.isAuthenticated()){
        util.findUserWithUsername(req,res,res.locals.currentUser.username,"/home", (user) => {
            res.render("register/old",{user : user});
        })
    } else {
        req.flash("error","Request Unauthorized");
        res.redirect("/login/authenticator");
    }
})

router.post("/register/old/complete", (req,res) => {
    req.flash("success","Authenticator Registration Successful");
    res.redirect("/home");
})

router.get("/register/new",(req,res) => {
    res.render("register/new");
})

router.get("/logout",(req,res) => {
    req.logout();
    req.flash("success","Successfully Logged Out");
    res.redirect("/");
})

module.exports = router;